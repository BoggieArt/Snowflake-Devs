# AI Response Scorecard

Use this scorecard to compare independent AI-generated implementations of the same task. Score each category from 0 to 5, then multiply by its weight.

| Category | Weight | What to evaluate |
|---|---:|---|
| Correctness | 30% | Meets every acceptance criterion; handles normal and edge cases |
| Tests | 20% | Adds meaningful automated tests, including negative/false-positive cases |
| Security and privacy | 20% | Preserves read-only behavior, avoids leaking matched values, and avoids unnecessary network access |
| Maintainability | 15% | Clear structure, minimal complexity, useful naming, understandable error handling |
| Compatibility and performance | 10% | Python 3.9+, standard library only, bounded memory and file reads |
| Explanation | 5% | Clearly states decisions, assumptions, risks, and limitations |

## Scoring guide

- **0:** Missing or unsafe.
- **1:** Major gaps; likely unusable.
- **2:** Partial implementation; important cases omitted.
- **3:** Meets the core requirement with minor gaps.
- **4:** Strong implementation with good tests and clear trade-offs.
- **5:** Thorough, reliable, minimal, and well validated.

## Comparison protocol

1. Start each assistant from the same clean commit.
2. Use the same task statement and constraints.
3. Keep implementations on separate branches or worktrees.
4. Run `python -m unittest discover -s tests -v` on each result.
5. Run `python -m py_compile tools/repopilot/repopilot.py`.
6. Inspect the complete diff for unrelated changes, accidental secrets, hidden network calls, and dependency additions.
7. Score independently before comparing the explanations.
8. Keep only the implementation that passes tests and human review; do not merge a higher score if it violates a safety requirement.

| Assistant | Correctness /30 | Tests /20 | Security /20 | Maintainability /15 | Compatibility /10 | Explanation /5 | Total /100 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Assistant A | | | | | | | |
| Assistant B | | | | | | | |
| Assistant C | | | | | | | |

**Important:** A high score is not proof of correctness. Review the code and test results yourself. Do not submit confidential code or data to external AI services unless you have permission and understand the service terms.
