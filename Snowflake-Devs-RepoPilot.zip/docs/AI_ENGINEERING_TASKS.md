# AI Engineering Task Brief — RepoPilot

This document defines small, testable engineering tasks for improving RepoPilot with coding assistants. It is designed for fair side-by-side evaluation: give each assistant the same task, repository snapshot, prompt, and test command.

## Project contract

- Python 3.9+, standard library only.
- Read-only scanning of the target project.
- No network requests, analytics, telemetry, or source uploads.
- Never write matched credential values into logs or reports.
- Bound file reads and skip generated/dependency directories.
- Every new behavior needs automated tests, including false-positive coverage.

## Task A — Respect Git ignore rules

**Goal:** Add optional Git-aware exclusion so files ignored by the project's `.gitignore` are not scanned, without introducing a Python dependency.

**Acceptance criteria:**
1. Reuse the installed Git CLI only when the target is a Git working tree and Git is available.
2. Keep a safe fallback for directories without Git.
3. Do not follow symlinks outside the repository.
4. Add tests for ignored files, negated ignore rules if supported, nested `.gitignore` files, missing Git, and non-Git folders.
5. Document any limitations of Git's ignore semantics.

## Task B — Improve secret detection safely

**Goal:** Add configurable patterns for a small set of commonly used credential formats.

**Acceptance criteria:**
1. Keep patterns narrowly scoped to reduce false positives.
2. Report only pattern name, relative path, and line number; never output the matching content.
3. Add positive and negative tests for every pattern.
4. Do not transmit content or call remote services.
5. Document that matches require human verification and exposed credentials should be rotated.

## Task C — Add machine-readable output stability

**Goal:** Define and test a stable JSON report schema.

**Acceptance criteria:**
1. Document required top-level fields and finding fields.
2. Add a schema/version field before making incompatible changes.
3. Keep report ordering deterministic except for the generated timestamp and absolute root path.
4. Add tests for empty projects, multiple severities, and serialization.

## Task D — Improve performance for large repositories

**Goal:** Reduce scan time and memory use without skipping relevant source files.

**Acceptance criteria:**
1. Continue to cap individual text-file reads.
2. Avoid loading the full repository into memory.
3. Keep traversal deterministic and symlink-safe.
4. Add a repeatable benchmark fixture and report elapsed time without a brittle hard timing assertion in unit tests.
5. Demonstrate no change in existing security tests.

## Suggested evaluation prompt

"Inspect the RepoPilot source and implement Task [A/B/C/D] from `docs/AI_ENGINEERING_TASKS.md`. Preserve the project contract. First explain your approach and risks, then make the smallest maintainable implementation, add automated tests for success and failure cases, run the full test suite, and summarize changed files, test results, limitations, and any assumptions. Do not add third-party dependencies or weaken secret redaction."
