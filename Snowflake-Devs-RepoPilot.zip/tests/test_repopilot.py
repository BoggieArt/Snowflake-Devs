import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "tools" / "repopilot"))

import repopilot  # noqa: E402


class RepoPilotTests(unittest.TestCase):
    def make_project(self, root: Path) -> None:
        (root / "README.md").write_text("# Fixture\n", encoding="utf-8")
        (root / ".gitignore").write_text(".env\n", encoding="utf-8")

    def test_detects_token_without_leaking_value(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.make_project(root)
            token = "ghp_" + "A" * 36
            (root / "app.py").write_text("TOKEN = '" + token + "'\n", encoding="utf-8")
            report = repopilot.scan_repository(root, root / "reports")
            self.assertEqual(report["summary"]["high"], 1)
            serialized = json.dumps(report)
            self.assertNotIn(token, serialized)
            self.assertIn("line 1", serialized)

    def test_scans_dotenv_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.make_project(root)
            (root / ".env").write_text('PASSWORD="' + "example-secret-value-" + "123" + '"\n', encoding="utf-8")
            report = repopilot.scan_repository(root, root / "reports")
            self.assertGreaterEqual(report["summary"]["high"], 1)
            self.assertTrue(any(x.get("path") == ".env" for x in report["findings"]))

    def test_scans_named_env_variants(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.make_project(root)
            (root / ".env.staging").write_text(
                'API_KEY="' + "example-staging-secret-" + "12345" + '"\n', encoding="utf-8"
            )
            report = repopilot.scan_repository(root, root / "reports")
            self.assertTrue(any(x.get("path") == ".env.staging" for x in report["findings"]))

    def test_skips_dependency_and_output_directories(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.make_project(root)
            (root / "node_modules").mkdir()
            (root / "node_modules" / "secret.js").write_text(
                "TOKEN='" + ("ghp_" + "B" * 36) + "'", encoding="utf-8"
            )
            output = root / ".repopilot-reports"
            output.mkdir()
            (output / "previous.txt").write_text("old report", encoding="utf-8")
            report = repopilot.scan_repository(root, output)
            self.assertEqual(report["summary"]["high"], 0)
            self.assertEqual(report["summary"]["files_scanned"], 2)

    def test_missing_project_docs_are_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            report = repopilot.scan_repository(root, root / "reports")
            categories = [x["category"] for x in report["findings"]]
            self.assertEqual(categories.count("project-hygiene"), 2)

    def test_markdown_report_contains_summary_and_limitations(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.make_project(root)
            report = repopilot.scan_repository(root, root / "reports")
            markdown = repopilot.render_markdown(report)
            self.assertIn("# RepoPilot Audit Report", markdown)
            self.assertIn("## Limitations", markdown)


if __name__ == "__main__":
    unittest.main()
