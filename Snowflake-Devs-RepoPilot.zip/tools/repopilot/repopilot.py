#!/usr/bin/env python3
"""RepoPilot: a dependency-free, read-only repository health scanner."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

VERSION = "1.0.0"
SKIP_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "node_modules", "vendor",
    "__pycache__", ".mypy_cache", ".pytest_cache", "dist", "build",
    "coverage", ".next", ".nuxt", ".cache", ".turbo",
}
TEXT_SUFFIXES = {
    ".py", ".php", ".js", ".jsx", ".ts", ".tsx", ".json", ".yml",
    ".yaml", ".toml", ".ini", ".md", ".txt", ".sh", ".ps1", ".html",
    ".css", ".scss", ".xml", ".sql", ".java", ".go", ".rs", ".rb",
    ".config", ".conf", ".properties", ".env",
}
TEXT_FILENAMES = {
    ".env", ".env.local", ".env.development", ".env.production",
    "dockerfile", "makefile", "procfile", "gemfile", "rakefile",
}
MAX_FILE_BYTES = 2 * 1024 * 1024
LARGE_FILE_BYTES = 10 * 1024 * 1024

# Report the category and line number only. Never include the matched value.
SECRET_PATTERNS = [
    ("Possible private key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("Possible AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Possible GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b")),
    (
        "Possible credential assignment",
        re.compile(
            r"(?i)\b(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)\b"
            r"\s*[:=]\s*['\"][^'\"\s]{12,}['\"]"
        ),
    ),
]


def add_finding(
    findings: List[Dict[str, Any]],
    severity: str,
    category: str,
    message: str,
    path: Optional[str] = None,
    recommendation: str = "",
) -> None:
    item: Dict[str, Any] = {
        "severity": severity,
        "category": category,
        "message": message,
    }
    if path:
        item["path"] = path
    if recommendation:
        item["recommendation"] = recommendation
    findings.append(item)


def iter_files(root: Path) -> Iterator[Path]:
    """Yield regular files below root without following directory symlinks."""
    for current, dirs, names in os.walk(root, followlinks=False):
        current_path = Path(current)
        dirs[:] = [
            name for name in sorted(dirs)
            if name not in SKIP_DIRS and not (current_path / name).is_symlink()
        ]
        for name in sorted(names):
            path = current_path / name
            try:
                if not path.is_symlink() and path.is_file():
                    yield path
            except OSError:
                continue


def is_text_candidate(path: Path) -> bool:
    name = path.name.lower()
    return (
        path.suffix.lower() in TEXT_SUFFIXES
        or name in TEXT_FILENAMES
        or name.startswith(".env.")
    )


def scan_repository(root: Path, output_dir: Path) -> Dict[str, Any]:
    findings: List[Dict[str, Any]] = []
    files_scanned = 0
    total_size = 0
    php_files: List[Path] = []

    readmes = ("README.md", "README.rst", "README.txt")
    if not any((root / name).is_file() for name in readmes):
        add_finding(
            findings, "medium", "project-hygiene", "README file is missing.",
            recommendation="Add a project overview, requirements, and setup instructions.",
        )
    if not (root / ".gitignore").is_file():
        add_finding(
            findings, "medium", "project-hygiene", ".gitignore is missing.",
            recommendation="Ignore local secrets, caches, generated output, and dependencies.",
        )

    for path in iter_files(root):
        try:
            resolved = path.resolve()
            if resolved == output_dir or output_dir in resolved.parents:
                continue
            relative = path.relative_to(root).as_posix()
            size = path.stat().st_size
        except (OSError, ValueError):
            continue

        files_scanned += 1
        total_size += size

        if size >= LARGE_FILE_BYTES:
            add_finding(
                findings, "medium", "repository-size",
                "Large file detected ({:.1f} MiB).".format(size / (1024 * 1024)),
                relative,
                "Check whether this is a required asset; consider Git LFS or excluding generated files.",
            )

        if path.suffix.lower() == ".php":
            php_files.append(path)

        if not is_text_candidate(path) or size > MAX_FILE_BYTES:
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue

        for label, pattern in SECRET_PATTERNS:
            for match in pattern.finditer(content):
                line_number = content.count("\n", 0, match.start()) + 1
                add_finding(
                    findings, "high", "possible-secret",
                    "{} pattern matched on line {}.".format(label, line_number),
                    relative,
                    "Verify safely. Remove exposed credentials, rotate any potentially exposed value, and use environment variables or a secret manager.",
                )

    php_binary = shutil.which("php")
    php_summary: Dict[str, Any] = {
        "available": bool(php_binary),
        "checked": 0,
        "failed": [],
    }
    if php_binary:
        for php_file in php_files:
            try:
                result = subprocess.run(
                    [php_binary, "-l", str(php_file)],
                    capture_output=True,
                    text=True,
                    timeout=15,
                    check=False,
                )
                php_summary["checked"] += 1
                if result.returncode != 0:
                    relative = php_file.relative_to(root).as_posix()
                    php_summary["failed"].append(relative)
                    add_finding(
                        findings, "high", "php-syntax", "PHP syntax check failed.",
                        relative,
                        "Run php -l locally and correct the reported parse error.",
                    )
            except (OSError, subprocess.TimeoutExpired):
                add_finding(
                    findings, "low", "php-syntax", "PHP lint could not complete.",
                    php_file.relative_to(root).as_posix(),
                    "Run php -l manually in a local development environment.",
                )

    counts = {
        level: sum(1 for item in findings if item["severity"] == level)
        for level in ("high", "medium", "low")
    }
    return {
        "tool": "RepoPilot",
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "root": str(root),
        "summary": {
            "files_scanned": files_scanned,
            "total_size_bytes": total_size,
            "high": counts["high"],
            "medium": counts["medium"],
            "low": counts["low"],
            "status": "needs-attention" if counts["high"] else "review",
        },
        "php": php_summary,
        "findings": findings,
        "limitations": [
            "Credential detection is heuristic and may produce false positives or false negatives.",
            "No dependency vulnerability database is queried.",
            "A clean report is not a security certification.",
        ],
    }


def render_markdown(report: Dict[str, Any]) -> str:
    summary = report["summary"]
    lines = [
        "# RepoPilot Audit Report", "",
        "- Generated: {}".format(report["generated_at"]),
        "- Scanned root: `{}`".format(report["root"]),
        "- Files scanned: **{}**".format(summary["files_scanned"]),
        "- High: **{}** | Medium: **{}** | Low: **{}**".format(
            summary["high"], summary["medium"], summary["low"]
        ),
        "- Status: **{}**".format(summary["status"]), "", "## Findings", "",
    ]
    if not report["findings"]:
        lines.append("No findings from the enabled checks.")
    for item in report["findings"]:
        location = " — `{}`".format(item["path"]) if item.get("path") else ""
        lines.extend([
            "### [{}] {}{}".format(item["severity"].upper(), item["category"], location),
            item["message"],
        ])
        if item.get("recommendation"):
            lines.append("**Recommended action:** {}".format(item["recommendation"]))
        lines.append("")

    php = report["php"]
    lines.extend([
        "## PHP lint", "",
        "- PHP CLI available: **{}**".format(php["available"]),
        "- Files checked: **{}**".format(php["checked"]),
        "- Failed files: **{}**".format(len(php["failed"])),
        "", "## Limitations", "",
    ])
    lines.extend("- {}".format(item) for item in report["limitations"])
    return "\n".join(lines) + "\n"


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run a read-only repository health and safety audit."
    )
    parser.add_argument("root", nargs="?", default=".", help="Project directory to scan")
    parser.add_argument(
        "--out", default=None,
        help="Directory for JSON and Markdown reports (default: ROOT/.repopilot-reports)",
    )
    args = parser.parse_args(argv)

    root = Path(args.root).expanduser().resolve()
    output_dir = (
        Path(args.out).expanduser().resolve()
        if args.out else root / ".repopilot-reports"
    )
    if not root.exists() or not root.is_dir():
        print("Error: project directory does not exist: {}".format(root), file=sys.stderr)
        return 2

    try:
        report = scan_repository(root, output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        markdown_path = output_dir / "repopilot-report.md"
        json_path = output_dir / "repopilot-report.json"
        markdown_path.write_text(render_markdown(report), encoding="utf-8")
        json_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    except OSError as exc:
        print("Error: {}".format(exc), file=sys.stderr)
        return 2

    summary = report["summary"]
    print("RepoPilot scanned {} files.".format(summary["files_scanned"]))
    print("Findings: {} high, {} medium, {} low.".format(
        summary["high"], summary["medium"], summary["low"]
    ))
    print("Reports: {} and {}".format(markdown_path, json_path))
    return 1 if summary["high"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
