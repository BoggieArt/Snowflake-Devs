# RepoPilot

RepoPilot is a dependency-free, read-only repository health scanner. See the [root README](../../README.md) for setup, examples, exit codes, and the AI-assisted engineering workflow.

Run from the repository root:

```bash
python tools/repopilot/repopilot.py
```
